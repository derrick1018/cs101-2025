/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void multi(int j, int i) {
    if (i>9) return; {
        printf("%d*%d=%d\n", i, j, i*j);
        multi(j, i+1);
        
    }
    
}

void full_table(int j) {
    if (j>9) return; {
        multi(j, 1);
        printf("\n");
        full_table(j+1);
        
    }
    
}
int main()
{
    full_table(1);

    return 0;
}
