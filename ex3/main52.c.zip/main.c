/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int func(int* i, int* j) {
    printf("in func, i = %d, j = %d\n", *i, *j);
    int t;
    t = *j;
    *j = *i;
    *i = t;
    printf("in func, i = %d, j = %d\n", *i, *j);
}

int main()
{
    int n=1, m=2;
    func(&n, &m);
    printf("in main, n = %d, m = %d\n", n, m);

    return 0;
}
